//
//  InboxViewControllerTableViewController.h
//  Ribbit
//
//  Created by Latiesha Caston on 12/5/15.
//  Copyright © 2015 Latiesha Caston. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InboxViewControllerTableViewController : UITableViewController


- (IBAction)logout:(id)sender;





@end
